#include "escenario.h"
#include <stdio.h>
#include <string.h>

Galaxia universo[MAX_GALAXIAS];
Nave nave;
int num_galaxias = 0;
int nave_fuera_sistema = 0;

// Función para encontrar una galaxia por su id (nombre)
int encontrar_galaxia(const char* id) {
    for (int i = 0; i < num_galaxias; i++) {
        if (strcmp(universo[i].id, id) == 0) {
            return i;
        }
    }
    return -1; // No encontrada
}

void imprimir_universo() {
    printf("Estructura del universo:\n");
    for (int i = 0; i < num_galaxias; i++) {
        // Imprimir simplemente el nombre de la galaxia o subgalaxia
        printf("%s\n", universo[i].id);
        
        // Imprimir las conexiones de la galaxia/subgalaxia
        for (int j = 0; j < universo[i].num_conexiones; j++) {
            int conexion = universo[i].conexiones[j];
            int peso = universo[i].pesos[j];
            printf("  Conectada a %s con peso %d\n", universo[conexion].id, peso);
        }
    }
}


// Función para agregar una galaxia al universo
void agregar_galaxia(const char* id, int esReabastecimiento, int esSubgalaxia) {
    if (num_galaxias >= MAX_GALAXIAS) {
        printf("Error: Límite de galaxias alcanzado.\n");
        return;
    }
    
    strcpy(universo[num_galaxias].id, id); 
    universo[num_galaxias].esReabastecimiento = esReabastecimiento;
    universo[num_galaxias].num_conexiones = 0;
    
    // Si es una subgalaxia
    if (esSubgalaxia) {
        printf("Subgalaxia %s agregada al universo %sreabastecimiento.\n", id, esReabastecimiento ? "con " : "sin ");
    } else {
        printf("Galaxia %s agregada al universo %sreabastecimiento.\n", id, esReabastecimiento ? "con " : "sin ");
    }
    
    num_galaxias++;
}

// Función para agregar una conexión (arista) entre dos galaxias
void agregar_arista(int origen, int destino, int peso) {
    if (origen < 0 || destino < 0 || origen >= num_galaxias || destino >= num_galaxias) {
        printf("Error: Índice de galaxia inválido.\n");
        return;
    }

    universo[origen].conexiones[universo[origen].num_conexiones] = destino;
    universo[origen].pesos[universo[origen].num_conexiones] = peso;
    universo[origen].num_conexiones++;

    universo[destino].conexiones[universo[destino].num_conexiones] = origen;
    universo[destino].pesos[universo[destino].num_conexiones] = peso;
    universo[destino].num_conexiones++;

    printf("Arista entre %s y %s con peso %d agregada.\n", universo[origen].id, universo[destino].id, peso);
}

// Función para crear una nave
void crear_nave(int combustible_inicial, int ubicacion_inicial) {
    nave.combustible = combustible_inicial;
    nave.ubicacion = ubicacion_inicial;
    printf("Nave creada con %d de combustible en %s.\n", combustible_inicial, universo[ubicacion_inicial].id);
    //imprimir_universo();
}

//Función desarrollada por gpt
void viajar_autonomo(int destino, int modo) {
    //imprimir_universo();
    if (destino < 0 || destino >= num_galaxias) {
        printf("Error: Destino no encontrado en el universo.\n");
        return;
    }

    if (modo == 1) {
        // Modo 1: Menor consumo de combustible (Dijkstra)
        printf("Modo 1: Menor consumo de combustible hacia galaxia %s.\n", universo[destino].id);

        
        int dist[MAX_GALAXIAS];  // Distancia mínima a cada galaxia
        int prev[MAX_GALAXIAS];  // Guardar el camino
        int visitado[MAX_GALAXIAS] = {0};  // Marcar si ya se visitó

        // Inicializando distancias a infinito
        for (int i = 0; i < MAX_GALAXIAS; i++) {
            dist[i] = 1000000;  // Simular infinito
            prev[i] = -1;  // Sin predecesor al inicio
        }

        dist[nave.ubicacion] = 0;  // La distancia a la galaxia de origen es 0

        
        for (int i = 0; i < num_galaxias; i++) {
            int u = -1;

            // Encontrar la galaxia no visitada con la menor distancia
            for (int j = 0; j < num_galaxias; j++) {
                if (!visitado[j] && (u == -1 || dist[j] < dist[u])) {
                    u = j;
                }
            }

            if (u == -1 || dist[u] == 1000000) break;  // No hay más conexiones

            visitado[u] = 1;  // Marcar la galaxia como visitada

            // Relajar las conexiones de la galaxia actual
            for (int j = 0; j < universo[u].num_conexiones; j++) {
                int v = universo[u].conexiones[j];  // Galaxia vecina
                int peso = universo[u].pesos[j];    // Peso de la conexión

                if (dist[u] + peso < dist[v]) {
                    dist[v] = dist[u] + peso;
                    prev[v] = u;  // Guardar el camino
                }
            }
        }

        // Verificar si se encontró un camino al destino
        if (dist[destino] == 1000000) {
            printf("No se encontró un camino a la galaxia %s.\n", universo[destino].id);
            return;
        }

        // **Recorrer el camino desde la ubicación actual hasta el destino**
        int actual = destino;
        int path[MAX_GALAXIAS];  // Para almacenar el camino
        int steps = 0;  // Contador de pasos

        // Guardar el camino en orden inverso (desde el destino hacia el origen)
        while (actual != nave.ubicacion) {
            path[steps++] = actual;  // Almacenar la galaxia
            actual = prev[actual];
            if (actual == -1) {
                printf("Error: camino inválido.\n");
                return;
            }
        }
        path[steps++] = nave.ubicacion;  // Incluir la ubicación inicial

        // Ahora imprimir el camino en orden correcto (desde el origen al destino)
        printf("Ruta óptima:\n");
        for (int i = steps - 1; i > 0; i--) {
            int next = path[i - 1];
            int consumo = 0;

            // Encontrar el peso de la conexión entre path[i] y next
            for (int j = 0; j < universo[path[i]].num_conexiones; j++) {
                if (universo[path[i]].conexiones[j] == next) {
                    consumo = universo[path[i]].pesos[j];
                    break;
                }
            }

            if (nave.combustible >= consumo) {
                nave.combustible -= consumo;
                printf("Viajando de %s a %s, combustible restante: %d\n", universo[path[i]].id, universo[next].id, nave.combustible);
            } else {
                printf("Combustible insuficiente para completar el viaje.\n");
                return;
            }
        }

        // Llegada al destino
        nave.ubicacion = destino;  // Actualizar la ubicación de la nave
        printf("Llegaste a la galaxia %s con éxito. Combustible restante: %d.\n", universo[destino].id, nave.combustible);
    }
    // Modo 2 (menor cantidad de galaxias) se mantendrá igual
    else if (modo == 2) {
        // Modo 2: Menor cantidad de galaxias
        printf("Modo 2: Menor cantidad de galaxias hacia galaxia %s.\n", universo[destino].id);

        int prev[MAX_GALAXIAS];
        int visitado[MAX_GALAXIAS] = {0};

        // Inicializar BFS
        int queue[MAX_GALAXIAS];
        int front = 0, back = 0;
        queue[back++] = nave.ubicacion;
        visitado[nave.ubicacion] = 1;
        prev[nave.ubicacion] = -1;

        // BFS para encontrar el camino con menos galaxias
        while (front < back) {
            int u = queue[front++];
            for (int i = 0; i < universo[u].num_conexiones; i++) {
                int v = universo[u].conexiones[i];
                if (!visitado[v]) {
                    visitado[v] = 1;
                    prev[v] = u;
                    queue[back++] = v;

                    if (v == destino) break;  // Si llegamos al destino, terminamos
                }
            }
        }

        if (!visitado[destino]) {
            printf("No se encontró un camino a la galaxia %s.\n", universo[destino].id);
            return;
        }

        // **Reconstruir el camino** desde el destino hacia el origen
        int actual = destino;
        int path[MAX_GALAXIAS];
        int steps = 0;

        while (actual != -1) {
            path[steps++] = actual;
            actual = prev[actual];
        }

        // **Imprimir el camino en orden inverso** (del origen al destino)
        printf("Ruta óptima:\n");
        for (int i = steps - 1; i > 0; i--) {
            int next = path[i - 1];
            int consumo = 0;

            // Encontrar el peso de la conexión entre path[i] y next
            for (int j = 0; j < universo[path[i]].num_conexiones; j++) {
                if (universo[path[i]].conexiones[j] == next) {
                    consumo = universo[path[i]].pesos[j];
                    break;
                }
            }

            if (nave.combustible >= consumo) {
                nave.combustible -= consumo;
                printf("Viajando de %s a %s, combustible restante: %d\n", universo[path[i]].id, universo[next].id, nave.combustible);
            } else {
                printf("Combustible insuficiente para completar el viaje.\n");
                return;
            }
        }

        // Llegada al destino
        nave.ubicacion = destino;
        printf("Llegaste a la galaxia %s con éxito. Combustible restante: %d.\n", universo[destino].id, nave.combustible);
    }
}

// Función para viajar de forma guiada
void viajar_guiado(int destino) {
    // Verificar si hay una conexión directa con el destino
    int conexion_encontrada = 0;
    int consumo = 0;

    for (int i = 0; i < universo[nave.ubicacion].num_conexiones; i++) {
        if (universo[nave.ubicacion].conexiones[i] == destino) {
            consumo = universo[nave.ubicacion].pesos[i]; // Obtener el peso de la conexión
            conexion_encontrada = 1;
            break;
        }
    }

    if (conexion_encontrada) {
        if (nave.combustible >= consumo) {
            nave.combustible -= consumo;
            nave.ubicacion = destino;
            printf("La nave ha viajado a la galaxia %s y tiene %d de combustible restante.\n", universo[destino].id, nave.combustible);
        } else {
            printf("Combustible insuficiente para llegar a la galaxia %s.\n", universo[destino].id);
        }
    } else {
        printf("Error: La galaxia %s no es accesible directamente desde la galaxia actual.\n", universo[destino].id);
    }
}

// Función para reabastecer combustible en una galaxia de reabastecimiento
void reabastecer_combustible() {
    if (universo[nave.ubicacion].esReabastecimiento) {
        nave.combustible = 100; // Reabastecemos al máximo
        printf("La nave ha sido reabastecida en la galaxia %s.\n", universo[nave.ubicacion].id);
    } else {
        printf("La galaxia %s no permite reabastecimiento.\n", universo[nave.ubicacion].id);
    }
}

// Función para mostrar galaxias vecinas dentro de un radio dado
void mostrar_vecinos(int radio) {
    printf("Galaxias vecinas dentro del radio %d desde %s:\n", radio, universo[nave.ubicacion].id);
    for (int i = 0; i < universo[nave.ubicacion].num_conexiones; i++) {
        int vecino = universo[nave.ubicacion].conexiones[i];
        printf("Galaxia %s a distancia 1\n", universo[vecino].id);
    }
}
