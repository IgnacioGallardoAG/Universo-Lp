#ifndef ESCENARIO_H
#define ESCENARIO_H

#define MAX_GALAXIAS 100
#define MAX_CONEXIONES 10

typedef struct {
    char id[50]; // Identificador de la galaxia
    int conexiones[MAX_CONEXIONES]; // Índices de galaxias conectadas
    int pesos[MAX_CONEXIONES]; // Pesos de las conexiones
    int num_conexiones; // Número de conexiones actuales
    int esReabastecimiento; // 1 si permite reabastecer, 0 si no
} Galaxia;

typedef struct {
    int combustible;
    int ubicacion; // Índice de la galaxia actual
} Nave;

extern int nave_fuera_sistema;

// Declaración de funciones
void agregar_galaxia(const char* id, int esReabastecimiento, int esSubgalaxia);
void agregar_arista(int origen, int destino, int peso);
void crear_nave(int combustible_inicial, int ubicacion_inicial);

// Funciones para la Parte 2
void viajar_autonomo(int destino, int modo);
void viajar_guiado(int destino);
void reabastecer_combustible();
void mostrar_vecinos(int radio);
int encontrar_galaxia(const char* id);

#endif // ESCENARIO_H
